^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package iris_lama
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.0 (2021-04-10)
-----------
* Expose localization covariance

1.1.0 (2020-12-05)
-----------
* Expose the global localization parameters as options
* Add option to mark free cells when there is no hit in SLAM (i.e. truncated ranges)
* Add non-motion update trigger to location
* Fix infinite loop in global localization
* Use C++14
* Fix eigen aligment issues

1.0.0 (2020-05-05)
-----------
* First official release.
